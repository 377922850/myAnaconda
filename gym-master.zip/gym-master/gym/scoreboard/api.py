def upload(*args, **kwargs):
    raise NotImplementedError('The Gym website has been end-of-lifed. This library is the focus of the project. See https://github.com/openai/gym/issues/718#issuecomment-329661594 for details.')
